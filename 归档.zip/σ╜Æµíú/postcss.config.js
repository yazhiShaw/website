const autoprefixer = require('autoprefixer')

module.exports = {
    plugins: [
        // 浏览器前缀的自动优化
        autoprefixer()
    ]
}